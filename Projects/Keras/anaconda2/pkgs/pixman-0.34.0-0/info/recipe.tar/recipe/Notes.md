To compile this package on Windows you need to install MSYS and add it to
your PATH:

http://www.mingw.org/wiki/msys
