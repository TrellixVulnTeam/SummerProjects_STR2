from chest import Chest

c = Chest()
c['x'] = [1, 2, 3]
