#!/bin/bash

unset ARCH

make
make install
