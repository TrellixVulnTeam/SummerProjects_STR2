#!/bin/bash

./configure --prefix=$PREFIX
make
make install
