#!/bin/bash

env
conda inspect linkages -p ${PREFIX} libiconv
