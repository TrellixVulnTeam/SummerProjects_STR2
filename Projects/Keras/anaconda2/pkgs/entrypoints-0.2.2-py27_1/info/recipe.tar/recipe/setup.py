from distutils.core import setup


setup(
    name='entrypoints',
    version='0.2.2',
    py_modules=['entrypoints'],
)
