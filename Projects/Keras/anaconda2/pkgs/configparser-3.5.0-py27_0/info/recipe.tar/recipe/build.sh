#!/bin/bash

$PYTHON setup.py install --old-and-unmanageable
rm -f $SP_DIR/*-nspkg.pth
