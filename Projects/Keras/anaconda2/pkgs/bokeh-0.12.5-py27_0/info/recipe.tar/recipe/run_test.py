import bokeh

print('bokeh.__version__: %s' % bokeh.__version__)
assert bokeh.__version__ == '0.12.5'
