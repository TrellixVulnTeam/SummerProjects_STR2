from heapdict import heapdict

hd = heapdict()
hd['foo'] = 10
hd['bar'] = 20
