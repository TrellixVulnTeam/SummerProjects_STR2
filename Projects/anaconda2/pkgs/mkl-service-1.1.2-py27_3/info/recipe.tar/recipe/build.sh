#!/bin/bash

$PYTHON setup.py install

rm $SP_DIR/*.egg-info
