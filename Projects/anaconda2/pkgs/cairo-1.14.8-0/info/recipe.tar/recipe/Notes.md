To compile this package on Windows you need to:

1. Install MSYS and add it to your PATH: http://www.mingw.org/wiki/msys
2. Download xz binaries, copy xz to unxz and add them to your PATH
