import binstar_client

print('binstar_client.__version__: %s' % binstar_client.__version__)
assert binstar_client.__version__.startswith('1.6.3')
