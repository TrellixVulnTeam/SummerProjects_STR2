# this file exists only to trick the conda-build test env creator to install
#    python of the correct version.  The actual tests are commands in meta.yaml.
